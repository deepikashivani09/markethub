# MarketHub: Multi-Vendor E-Commerce & Order Management Platform

React + Vite + Tailwind frontend, Node.js + Express backend, PostgreSQL database, Stripe payments.

## Quick start

Requirements: Node.js 18+ and PostgreSQL 14+ (or Docker).

```bash
# 1. Database (skip if you already run Postgres; then edit backend/.env)
docker compose up -d

# 2. Backend  -> http://localhost:4000
cd backend
npm install
npm run db:setup      # creates tables and demo data
npm run dev

# 3. Frontend (new terminal) -> http://localhost:5173
cd frontend
npm install
npm run dev
```

`backend/.env` is already created with working local defaults. Change `JWT_SECRET` before deploying.

## Demo accounts (password `Passw0rd!`)

| Role | Email |
| --- | --- |
| Super Admin | admin@markethub.test |
| Vendor | vendor1@markethub.test, vendor2@markethub.test |
| Customer | customer@markethub.test |

New vendors register as "pending" and must be approved from the admin dashboard before listing products.

## How the key features work

**Role-based access control.** JWT login; `authenticate` + `authorize('admin' | 'vendor' | 'customer')` middleware on every router, plus separate dashboards on the frontend (`ProtectedRoute`).

**Overselling protection** (`backend/src/services/orders.js`, `createOrderFromCart`). Checkout runs in one transaction. Each product is decremented with `UPDATE products SET stock = stock - qty WHERE id = $1 AND stock >= qty`. Postgres row-locks the product, so concurrent buyers are serialised and the loser gets "Not enough stock". Products are locked in id order to avoid deadlocks, and `CHECK (stock >= 0)` is a second safety net. Prove it yourself:

```bash
cd backend && npm run test:race   # 25 buyers race for 5 units; expects exactly 5 orders
```

Stock stays reserved while an order awaits payment. Unpaid orders are cancelled and stock is returned after `RESERVATION_MINUTES` (a job runs every minute). Cancelling any item also returns its stock.

**Order state machine** (`backend/src/utils/orderStateMachine.js`).
`pending -> packed -> shipped -> delivered`; `cancelled` is allowed only from pending or packed. Every line item has its own status (each vendor ships their own items) and the order status is derived from its items. Vendors can only touch their own items; customers can only cancel; shipping requires a paid order.

**Payments.**
- With no Stripe keys the app runs in **demo mode**: "Place order and pay" marks the order paid instantly so you can test the whole flow.
- For real Stripe: set `STRIPE_SECRET_KEY` and `STRIPE_WEBHOOK_SECRET` in `backend/.env`, then forward webhooks locally:
  ```bash
  stripe listen --forward-to localhost:4000/api/webhooks/stripe
  ```
  Orders are marked paid only by the signed `checkout.session.completed` webhook, never by the browser redirect. The webhook is idempotent. Currency defaults to INR (`CURRENCY` in `.env`).
- Razorpay instead? Replace `createCheckoutSession` in `services/payments.js` with a Razorpay order and verify its `payment.captured` webhook signature in `routes/webhooks.js`, then call `markOrderPaid`.

Refunds are tracked (`orders.refund_due_cents`) but not sent automatically; connect `stripe.refunds.create` where `refund_due_cents` is increased if you want that.

## Project layout

```
backend/
  sql/schema.sql              tables and constraints
  src/routes/                 auth, products, cart, orders, vendor, admin, webhooks
  src/services/orders.js      checkout, stock reservation, state transitions, expiry
  src/services/payments.js    Stripe Checkout session
  src/utils/orderStateMachine.js
  src/scripts/                migrate, seed, raceTest
frontend/src/
  pages/                      Shop, AuthPage, CartPage, OrdersPage, VendorDashboard, AdminDashboard
  components/                 Navbar, ProtectedRoute, Stepper, StatusBadge, ProductTile
```

## API summary

| Area | Endpoints |
| --- | --- |
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me` |
| Catalogue | `GET /api/products?search&category&minPrice&maxPrice&sort&page`, `GET /api/products/categories` |
| Cart (customer) | `GET /api/cart`, `PUT /api/cart/:productId {quantity}` |
| Orders (customer) | `POST /api/orders/checkout`, `POST /api/orders/:id/pay`, `POST /api/orders/:id/cancel`, `GET /api/orders` |
| Vendor | `GET/POST/PUT/DELETE /api/vendor/products`, `GET /api/vendor/order-items`, `PATCH /api/vendor/order-items/:id/status` |
| Admin | `GET /api/admin/stats`, `/users`, `/orders`, `PATCH /api/admin/users/:id/status` |
| Webhook | `POST /api/webhooks/stripe` |
