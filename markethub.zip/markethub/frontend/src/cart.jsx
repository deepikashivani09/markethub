import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { api } from './api.js';
import { useAuth } from './auth.jsx';

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [cart, setCart] = useState({ items: [], total_cents: 0 });

  const refresh = useCallback(async () => {
    if (user?.role !== 'customer') return setCart({ items: [], total_cents: 0 });
    setCart(await api('/cart'));
  }, [user]);

  useEffect(() => { refresh().catch(() => {}); }, [refresh]);

  const setQuantity = async (productId, quantity) => setCart(await api(`/cart/${productId}`, { method: 'PUT', body: { quantity } }));
  const count = cart.items.reduce((n, i) => n + i.quantity, 0);

  return <CartContext.Provider value={{ cart, count, refresh, setQuantity }}>{children}</CartContext.Provider>;
}
