import { useCallback, useEffect, useState } from 'react';
import { api, money, NEXT_STATUS } from '../api.js';
import { useAuth } from '../auth.jsx';
import StatusBadge from '../components/StatusBadge.jsx';

const EMPTY = { name: '', description: '', price: '', stock: '', category: '', image_url: '' };

function Products() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');
  const load = useCallback(() => api('/vendor/products').then(setProducts).catch((e) => setError(e.message)), []);
  useEffect(() => { load(); }, [load]);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    try {
      setError('');
      const body = { ...form, price: Number(form.price), stock: Number(form.stock) };
      await api(editing ? `/vendor/products/${editing}` : '/vendor/products', { method: editing ? 'PUT' : 'POST', body });
      setForm(EMPTY);
      setEditing(null);
      load();
    } catch (err) { setError(err.message); }
  };
  const edit = (p) => { setEditing(p.id); setForm({ name: p.name, description: p.description, price: p.price_cents / 100, stock: p.stock, category: p.category, image_url: p.image_url || '' }); };
  const remove = async (id) => { if (confirm('Remove this product from your shop?')) { await api(`/vendor/products/${id}`, { method: 'DELETE' }); load(); } };

  return (
    <div className="grid gap-8 lg:grid-cols-[340px_1fr]">
      <form onSubmit={save} className="panel h-fit space-y-3 p-5">
        <h2 className="font-bold">{editing ? 'Edit product' : 'Add a product'}</h2>
        <div><label className="label" htmlFor="pn">Name</label><input id="pn" className="input" required value={form.name} onChange={set('name')} /></div>
        <div><label className="label" htmlFor="pd">Description</label><textarea id="pd" rows={3} className="input" value={form.description} onChange={set('description')} /></div>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label" htmlFor="pp">Price (₹)</label><input id="pp" type="number" min="1" step="0.01" className="input" required value={form.price} onChange={set('price')} /></div>
          <div><label className="label" htmlFor="ps">Stock</label><input id="ps" type="number" min="0" className="input" required value={form.stock} onChange={set('stock')} /></div>
        </div>
        <div><label className="label" htmlFor="pc">Category</label><input id="pc" className="input" required value={form.category} onChange={set('category')} /></div>
        <div><label className="label" htmlFor="pi">Image URL (optional)</label><input id="pi" className="input" value={form.image_url} onChange={set('image_url')} /></div>
        {error && <p role="alert" className="text-sm text-rust">{error}</p>}
        <div className="flex gap-2">
          <button className="btn-primary">{editing ? 'Save changes' : 'Add product'}</button>
          {editing && <button type="button" className="btn-ghost" onClick={() => { setEditing(null); setForm(EMPTY); }}>Cancel</button>}
        </div>
      </form>

      <div className="panel overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line text-ink/60"><tr><th className="p-3">Product</th><th className="p-3">Price</th><th className="p-3">Stock</th><th className="p-3" /></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id} className="border-b border-line last:border-0">
                <td className="p-3 font-medium">{p.name}<span className="block text-xs font-normal text-ink/60">{p.category}</span></td>
                <td className="p-3">{money(p.price_cents)}</td>
                <td className={`p-3 ${p.stock <= 3 ? 'font-medium text-rust' : ''}`}>{p.stock}</td>
                <td className="space-x-2 p-3 text-right"><button className="btn-ghost" onClick={() => edit(p)}>Edit</button><button className="btn-danger" onClick={() => remove(p.id)}>Remove</button></td>
              </tr>
            ))}
            {products.length === 0 && <tr><td colSpan={4} className="p-8 text-center text-ink/60">No products yet. Add your first one using the form.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Orders() {
  const [items, setItems] = useState([]);
  const [error, setError] = useState('');
  const load = useCallback(() => api('/vendor/order-items').then(setItems).catch((e) => setError(e.message)), []);
  useEffect(() => { load(); }, [load]);

  const move = async (id, status) => {
    try { setError(''); await api(`/vendor/order-items/${id}/status`, { method: 'PATCH', body: { status } }); load(); }
    catch (e) { setError(e.message); }
  };

  return (
    <div className="panel overflow-x-auto">
      {error && <p role="alert" className="p-3 text-sm text-rust">{error}</p>}
      <table className="w-full text-left text-sm">
        <thead className="border-b border-line text-ink/60"><tr><th className="p-3">Order</th><th className="p-3">Item</th><th className="p-3">Customer</th><th className="p-3">Payment</th><th className="p-3">Status</th><th className="p-3">Update</th></tr></thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.id} className="border-b border-line align-top last:border-0">
              <td className="p-3">#{i.order_id}</td>
              <td className="p-3 font-medium">{i.name} × {i.quantity}<span className="block text-xs font-normal text-ink/60">{money(i.unit_price_cents * i.quantity)}</span></td>
              <td className="p-3">{i.customer_name}<span className="block max-w-[220px] truncate text-xs text-ink/60">{i.shipping_address}</span></td>
              <td className="p-3"><StatusBadge status={i.payment_status} /></td>
              <td className="p-3"><StatusBadge status={i.status} /></td>
              <td className="space-x-2 p-3">
                {i.payment_status === 'unpaid' && i.status === 'pending' && <span className="text-xs text-ink/60">Waiting for payment</span>}
                {NEXT_STATUS[i.status].map((s) => (
                  <button key={s} disabled={s !== 'cancelled' && i.payment_status !== 'paid'} className={s === 'cancelled' ? 'btn-danger' : 'btn-primary'} onClick={() => move(i.id, s)}>
                    {s === 'cancelled' ? 'Cancel' : `Mark ${s}`}
                  </button>
                ))}
              </td>
            </tr>
          ))}
          {items.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-ink/60">No orders for your shop yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

export default function VendorDashboard() {
  const { user } = useAuth();
  const [tab, setTab] = useState('orders');
  return (
    <div>
      <h1 className="text-2xl font-bold">{user.shop_name}</h1>
      {user.status !== 'active' ? (
        <p className="mt-4 rounded-md bg-marigold-soft px-4 py-3 text-sm">Your shop is waiting for admin approval. You can add products once it is approved.</p>
      ) : (
        <>
          <div className="my-5 flex gap-2" role="tablist">
            {['orders', 'products'].map((t) => (
              <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? 'btn-primary capitalize' : 'btn-ghost capitalize'} onClick={() => setTab(t)}>{t}</button>
            ))}
          </div>
          {tab === 'orders' ? <Orders /> : <Products />}
        </>
      )}
    </div>
  );
}
