import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api, money } from '../api.js';
import { useCart } from '../cart.jsx';
import ProductTile from '../components/ProductTile.jsx';

export default function CartPage() {
  const { cart, setQuantity, refresh } = useCart();
  const navigate = useNavigate();
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const change = async (id, qty) => {
    try { setError(''); await setQuantity(id, qty); } catch (e) { setError(e.message); }
  };

  const checkout = async () => {
    setBusy(true);
    setError('');
    try {
      // 1) Reserve stock atomically and create the order.
      const order = await api('/orders/checkout', { method: 'POST', body: { shippingAddress: address } });
      await refresh();
      // 2) Start payment: Stripe returns a hosted checkout URL; demo mode pays instantly.
      const pay = await api(`/orders/${order.id}/pay`, { method: 'POST' });
      if (pay.checkoutUrl) window.location.href = pay.checkoutUrl;
      else navigate(`/orders?paid=${order.id}`);
    } catch (e) {
      setError(e.message);
      await refresh();
    } finally {
      setBusy(false);
    }
  };

  if (cart.items.length === 0) {
    return (
      <div className="py-16 text-center">
        <h1 className="mb-2 text-2xl font-bold">Your cart is empty</h1>
        <Link to="/" className="btn-primary mt-2">Browse products</Link>
      </div>
    );
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <section>
        <h1 className="mb-4 text-2xl font-bold">Your cart</h1>
        <ul className="panel divide-y divide-line">
          {cart.items.map((i) => (
            <li key={i.product_id} className="flex items-center gap-4 p-4">
              <div className="w-20 shrink-0 overflow-hidden rounded"><ProductTile name={i.name} image_url={i.image_url} className="h-20" /></div>
              <div className="flex-1">
                <p className="font-bold">{i.name}</p>
                <p className="text-sm text-ink/60">{i.shop_name} · {money(i.price_cents)} each</p>
                {i.stock < i.quantity && <p className="text-sm text-rust">Only {i.stock} left. Lower the quantity to continue.</p>}
              </div>
              <div className="flex items-center gap-2">
                <button className="btn-ghost px-3" aria-label={`Decrease ${i.name}`} onClick={() => change(i.product_id, i.quantity - 1)}>−</button>
                <span className="w-6 text-center">{i.quantity}</span>
                <button className="btn-ghost px-3" aria-label={`Increase ${i.name}`} disabled={i.quantity >= i.stock} onClick={() => change(i.product_id, i.quantity + 1)}>+</button>
              </div>
              <p className="w-24 text-right font-bold">{money(i.price_cents * i.quantity)}</p>
            </li>
          ))}
        </ul>
      </section>

      <aside className="panel h-fit space-y-4 p-5">
        <div className="flex justify-between text-lg font-bold"><span>Total</span><span>{money(cart.total_cents)}</span></div>
        <div>
          <label className="label" htmlFor="address">Shipping address</label>
          <textarea id="address" rows={4} className="input" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Name, street, city, PIN code" />
        </div>
        {error && <p role="alert" className="text-sm text-rust">{error}</p>}
        <button className="btn-primary w-full" disabled={busy || address.trim().length < 10} onClick={checkout}>{busy ? 'Placing order…' : 'Place order and pay'}</button>
        <p className="text-xs text-ink/60">Stock is reserved when you place the order. Unpaid orders are released automatically.</p>
      </aside>
    </div>
  );
}
