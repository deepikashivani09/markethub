import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';

const HOME = { admin: '/admin', vendor: '/vendor', customer: '/' };

export default function AuthPage({ mode }) {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const isRegister = mode === 'register';
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'customer', shopName: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const user = isRegister
        ? await register({ ...form, shopName: form.role === 'vendor' ? form.shopName : undefined })
        : await login(form.email, form.password);
      navigate(HOME[user.role]);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <h1 className="mb-6 text-2xl font-bold">{isRegister ? 'Create your account' : 'Log in to MarketHub'}</h1>
      <form onSubmit={submit} className="panel space-y-4 p-6">
        {isRegister && (
          <>
            <div>
              <label className="label" htmlFor="role">I want to</label>
              <select id="role" className="input" value={form.role} onChange={set('role')}>
                <option value="customer">Buy products</option>
                <option value="vendor">Sell products</option>
              </select>
            </div>
            <div>
              <label className="label" htmlFor="name">Your name</label>
              <input id="name" className="input" required value={form.name} onChange={set('name')} />
            </div>
            {form.role === 'vendor' && (
              <div>
                <label className="label" htmlFor="shop">Shop name</label>
                <input id="shop" className="input" required value={form.shopName} onChange={set('shopName')} />
                <p className="mt-1 text-xs text-ink/60">An admin approves new shops before they can list products.</p>
              </div>
            )}
          </>
        )}
        <div>
          <label className="label" htmlFor="email">Email</label>
          <input id="email" type="email" className="input" required value={form.email} onChange={set('email')} />
        </div>
        <div>
          <label className="label" htmlFor="password">Password</label>
          <input id="password" type="password" className="input" required minLength={isRegister ? 8 : 1} value={form.password} onChange={set('password')} />
        </div>
        {error && <p role="alert" className="text-sm text-rust">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Please wait…' : isRegister ? 'Create account' : 'Log in'}</button>
        <p className="text-center text-sm text-ink/70">
          {isRegister ? <>Already registered? <Link className="font-medium text-leaf" to="/login">Log in</Link></> : <>New here? <Link className="font-medium text-leaf" to="/register">Create an account</Link></>}
        </p>
      </form>
      {!isRegister && (
        <p className="mt-4 text-sm text-ink/60">Demo accounts (after seeding), password <code>Passw0rd!</code>: customer@markethub.test, vendor1@markethub.test, admin@markethub.test</p>
      )}
    </div>
  );
}
