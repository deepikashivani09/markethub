import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { api, money } from '../api.js';
import StatusBadge from '../components/StatusBadge.jsx';
import Stepper from '../components/Stepper.jsx';

export default function OrdersPage() {
  const [params] = useSearchParams();
  const paidId = params.get('paid');
  const [orders, setOrders] = useState(null);
  const [error, setError] = useState('');

  const load = useCallback(() => api('/orders').then(setOrders).catch((e) => setError(e.message)), []);
  useEffect(() => { load(); }, [load]);

  // After returning from Stripe the webhook may land a moment later, so re-check a few times.
  useEffect(() => {
    if (!paidId) return;
    let n = 0;
    const t = setInterval(() => { load(); if (++n >= 5) clearInterval(t); }, 2000);
    return () => clearInterval(t);
  }, [paidId, load]);

  const act = async (id, action) => {
    try { setError(''); await api(`/orders/${id}/${action}`, { method: 'POST' }).then((r) => r.checkoutUrl && (window.location.href = r.checkoutUrl)); await load(); }
    catch (e) { setError(e.message); }
  };

  if (!orders) return <p className="text-ink/60">{error || 'Loading your orders…'}</p>;

  return (
    <div>
      <h1 className="mb-4 text-2xl font-bold">My orders</h1>
      {paidId && <p role="status" className="mb-4 rounded-md bg-leaf-soft px-4 py-2 text-sm text-leaf-dark">Thanks! Order #{paidId} is being confirmed. Its status updates here as vendors pack and ship it.</p>}
      {error && <p role="alert" className="mb-4 text-sm text-rust">{error}</p>}
      {orders.length === 0 && <p className="py-12 text-center text-ink/60">You have not placed any orders yet.</p>}
      <div className="space-y-5">
        {orders.map((o) => {
          const cancellable = o.status !== 'cancelled' && o.items.every((i) => ['pending', 'packed', 'cancelled'].includes(i.status));
          return (
            <section key={o.id} className="panel">
              <header className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-3">
                <div>
                  <p className="font-bold">Order #{o.id}</p>
                  <p className="text-xs text-ink/60">{new Date(o.created_at).toLocaleString()}</p>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={o.payment_status} />
                  <StatusBadge status={o.status} />
                  <span className="font-bold">{money(o.total_cents)}</span>
                </div>
              </header>
              <ul className="divide-y divide-line">
                {o.items.map((i) => (
                  <li key={i.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                    <div>
                      <p className="font-medium">{i.name} × {i.quantity}</p>
                      <p className="text-xs text-ink/60">Sold by {i.vendor_name}</p>
                    </div>
                    <Stepper status={i.status} />
                  </li>
                ))}
              </ul>
              <footer className="flex flex-wrap items-center justify-between gap-2 px-5 py-3">
                <p className="max-w-md truncate text-xs text-ink/60">Ship to: {o.shipping_address}</p>
                <div className="flex gap-2">
                  {o.payment_status === 'unpaid' && o.status !== 'cancelled' && <button className="btn-primary" onClick={() => act(o.id, 'pay')}>Pay now</button>}
                  {cancellable && <button className="btn-danger" onClick={() => act(o.id, 'cancel')}>Cancel order</button>}
                </div>
              </footer>
              {o.refund_due_cents > 0 && <p className="border-t border-line px-5 py-2 text-xs text-ink/70">{money(o.refund_due_cents)} will be refunded to your original payment method.</p>}
            </section>
          );
        })}
      </div>
    </div>
  );
}
