import { useCallback, useEffect, useState } from 'react';
import { api, money } from '../api.js';
import StatusBadge from '../components/StatusBadge.jsx';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const [s, u, o] = await Promise.all([api('/admin/stats'), api('/admin/users'), api('/admin/orders')]);
      setStats(s); setUsers(u); setOrders(o);
    } catch (e) { setError(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);

  const setStatus = async (id, status) => { await api(`/admin/users/${id}/status`, { method: 'PATCH', body: { status } }); load(); };

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Marketplace overview</h1>
      {error && <p role="alert" className="text-sm text-rust">{error}</p>}
      {stats && (
        <dl className="panel grid grid-cols-2 divide-line sm:grid-cols-3 lg:grid-cols-6 lg:divide-x">
          {[['Revenue', money(stats.revenue_cents)], ['Orders', stats.orders], ['Products', stats.products], ['Vendors', stats.vendors], ['Awaiting approval', stats.pending_vendors], ['Customers', stats.customers]].map(([k, v]) => (
            <div key={k} className="p-4"><dt className="text-xs text-ink/60">{k}</dt><dd className="text-2xl font-bold">{v}</dd></div>
          ))}
        </dl>
      )}

      <section>
        <h2 className="mb-3 font-bold">Users and vendors</h2>
        <div className="panel overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-ink/60"><tr><th className="p-3">Name</th><th className="p-3">Role</th><th className="p-3">Status</th><th className="p-3" /></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-b border-line last:border-0">
                  <td className="p-3 font-medium">{u.shop_name || u.name}<span className="block text-xs font-normal text-ink/60">{u.email}</span></td>
                  <td className="p-3 capitalize">{u.role}</td>
                  <td className="p-3"><StatusBadge status={u.status} /></td>
                  <td className="p-3 text-right">
                    {u.status !== 'active' && <button className="btn-primary" onClick={() => setStatus(u.id, 'active')}>{u.status === 'pending' ? 'Approve' : 'Reinstate'}</button>}
                    {u.status === 'active' && <button className="btn-danger" onClick={() => setStatus(u.id, 'suspended')}>Suspend</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-bold">Recent orders</h2>
        <div className="panel overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-line text-ink/60"><tr><th className="p-3">Order</th><th className="p-3">Customer</th><th className="p-3">Items</th><th className="p-3">Total</th><th className="p-3">Payment</th><th className="p-3">Status</th></tr></thead>
            <tbody>
              {orders.map((o) => (
                <tr key={o.id} className="border-b border-line last:border-0">
                  <td className="p-3">#{o.id}</td>
                  <td className="p-3">{o.customer_name}</td>
                  <td className="p-3">{o.items.length}</td>
                  <td className="p-3">{money(o.total_cents)}{o.refund_due_cents > 0 && <span className="block text-xs text-rust">Refund due {money(o.refund_due_cents)}</span>}</td>
                  <td className="p-3"><StatusBadge status={o.payment_status} /></td>
                  <td className="p-3"><StatusBadge status={o.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
