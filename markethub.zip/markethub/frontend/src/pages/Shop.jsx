import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, money } from '../api.js';
import { useAuth } from '../auth.jsx';
import { useCart } from '../cart.jsx';
import ProductTile from '../components/ProductTile.jsx';

export default function Shop() {
  const { user } = useAuth();
  const { cart, setQuantity } = useCart();
  const navigate = useNavigate();
  const [filters, setFilters] = useState({ search: '', category: '', minPrice: '', maxPrice: '', sort: 'newest', page: 1 });
  const [categories, setCategories] = useState([]);
  const [data, setData] = useState({ items: [], total: 0, pages: 1 });
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  useEffect(() => { api('/products/categories').then(setCategories).catch(() => {}); }, []);

  useEffect(() => {
    const t = setTimeout(() => {
      const qs = new URLSearchParams(Object.entries(filters).filter(([, v]) => v !== '' && v != null));
      api(`/products?${qs}`).then((d) => { setData(d); setError(''); }).catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [filters]);

  const set = (key, value) => setFilters((f) => ({ ...f, [key]: value, page: key === 'page' ? value : 1 }));

  const addToCart = async (product) => {
    if (!user) return navigate('/login');
    const inCart = cart.items.find((i) => i.product_id === product.id)?.quantity || 0;
    try {
      await setQuantity(product.id, inCart + 1);
      setNotice(`Added "${product.name}" to your cart`);
    } catch (e) {
      setNotice(e.message);
    }
    setTimeout(() => setNotice(''), 2500);
  };

  return (
    <div>
      <h1 className="mb-1 text-3xl font-bold tracking-tight">Shop from independent makers</h1>
      <p className="mb-6 text-ink/70">Every product ships directly from the vendor who made it.</p>

      <div className="panel mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-5">
        <input className="input lg:col-span-2" placeholder="Search products" aria-label="Search products" value={filters.search} onChange={(e) => set('search', e.target.value)} />
        <select className="input" aria-label="Category" value={filters.category} onChange={(e) => set('category', e.target.value)}>
          <option value="">All categories</option>
          {categories.map((c) => <option key={c}>{c}</option>)}
        </select>
        <select className="input" aria-label="Sort" value={filters.sort} onChange={(e) => set('sort', e.target.value)}>
          <option value="newest">Newest first</option>
          <option value="price_asc">Price: low to high</option>
          <option value="price_desc">Price: high to low</option>
        </select>
        <div className="flex gap-2">
          <input className="input" type="number" min="0" placeholder="Min ₹" aria-label="Minimum price" value={filters.minPrice} onChange={(e) => set('minPrice', e.target.value)} />
          <input className="input" type="number" min="0" placeholder="Max ₹" aria-label="Maximum price" value={filters.maxPrice} onChange={(e) => set('maxPrice', e.target.value)} />
        </div>
      </div>

      {notice && <p role="status" className="mb-4 rounded-md bg-leaf-soft px-4 py-2 text-sm text-leaf-dark">{notice}</p>}
      {error && <p role="alert" className="mb-4 rounded-md bg-rust-soft px-4 py-2 text-sm text-rust">{error}</p>}

      {data.items.length === 0 && !error ? (
        <p className="py-16 text-center text-ink/60">No products match these filters. Try a different search or clear the price range.</p>
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {data.items.map((p) => (
            <article key={p.id} className="panel flex flex-col overflow-hidden">
              <ProductTile name={p.name} image_url={p.image_url} />
              <div className="flex flex-1 flex-col p-4">
                <p className="text-xs text-ink/60">{p.shop_name} · {p.category}</p>
                <h2 className="mt-1 font-bold leading-snug">{p.name}</h2>
                <p className="mt-1 line-clamp-2 text-sm text-ink/70">{p.description}</p>
                <div className="mt-auto flex items-end justify-between pt-4">
                  <div>
                    <p className="text-lg font-bold">{money(p.price_cents)}</p>
                    <p className={`text-xs ${p.stock <= 3 ? 'font-medium text-rust' : 'text-ink/60'}`}>
                      {p.stock === 0 ? 'Sold out' : p.stock <= 3 ? `Only ${p.stock} left` : 'In stock'}
                    </p>
                  </div>
                  {(!user || user.role === 'customer') && (
                    <button className="btn-primary" disabled={p.stock === 0} onClick={() => addToCart(p)}>Add to cart</button>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {data.pages > 1 && (
        <div className="mt-8 flex items-center justify-center gap-3">
          <button className="btn-ghost" disabled={filters.page <= 1} onClick={() => set('page', filters.page - 1)}>Previous</button>
          <span className="text-sm text-ink/70">Page {filters.page} of {data.pages}</span>
          <button className="btn-ghost" disabled={filters.page >= data.pages} onClick={() => set('page', filters.page + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
