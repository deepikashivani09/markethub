// Generated artwork tile so the app works without hosting any images.
const TONES = ['#0E7C66', '#B4411C', '#1B2430', '#8A6A12', '#355C7D', '#6B4E71'];

export default function ProductTile({ name, image_url, className = 'h-40' }) {
  if (image_url) return <img src={image_url} alt={name} className={`${className} w-full object-cover`} loading="lazy" />;
  const tone = TONES[[...name].reduce((n, ch) => n + ch.charCodeAt(0), 0) % TONES.length];
  return (
    <div className={`${className} flex w-full items-center justify-center text-6xl font-bold text-white/90`} style={{ background: tone }} aria-hidden="true">
      {name.trim()[0]?.toUpperCase()}
    </div>
  );
}
