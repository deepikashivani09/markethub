const STYLES = {
  pending: 'bg-marigold-soft text-ink',
  packed: 'bg-leaf-soft text-leaf-dark',
  shipped: 'bg-leaf-soft text-leaf-dark',
  delivered: 'bg-leaf text-white',
  cancelled: 'bg-rust-soft text-rust',
  paid: 'bg-leaf text-white',
  unpaid: 'bg-marigold-soft text-ink',
  active: 'bg-leaf-soft text-leaf-dark',
  suspended: 'bg-rust-soft text-rust',
};

export default function StatusBadge({ status }) {
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${STYLES[status] || 'bg-line'}`}>{status}</span>;
}
