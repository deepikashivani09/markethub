import { FLOW } from '../api.js';

// Shows progress through Pending -> Packed -> Shipped -> Delivered.
export default function Stepper({ status }) {
  if (status === 'cancelled') return <p className="text-sm font-medium text-rust">Cancelled</p>;
  const current = FLOW.indexOf(status);
  return (
    <ol className="flex items-center gap-1 text-xs" aria-label={`Status: ${status}`}>
      {FLOW.map((step, i) => (
        <li key={step} className="flex items-center gap-1">
          <span className={`rounded px-2 py-0.5 capitalize ${i <= current ? 'bg-leaf text-white' : 'bg-line text-ink/60'}`}>{step}</span>
          {i < FLOW.length - 1 && <span className={`h-px w-3 ${i < current ? 'bg-leaf' : 'bg-line'}`} />}
        </li>
      ))}
    </ol>
  );
}
