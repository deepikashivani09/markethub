import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { useCart } from '../cart.jsx';

const linkClass = ({ isActive }) => `text-sm ${isActive ? 'font-bold text-leaf' : 'text-ink/70 hover:text-ink'}`;

export default function Navbar() {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const navigate = useNavigate();

  return (
    <header className="border-b border-line bg-white">
      <nav className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Link to="/" className="text-xl font-bold tracking-tight text-leaf">MarketHub</Link>
        <div className="flex items-center gap-5">
          <NavLink to="/" end className={linkClass}>Shop</NavLink>
          {user?.role === 'customer' && (
            <>
              <NavLink to="/orders" className={linkClass}>My orders</NavLink>
              <NavLink to="/cart" className={linkClass}>Cart{count > 0 && <span className="ml-1 rounded-full bg-marigold px-2 py-0.5 text-xs font-bold text-ink">{count}</span>}</NavLink>
            </>
          )}
          {user?.role === 'vendor' && <NavLink to="/vendor" className={linkClass}>Vendor dashboard</NavLink>}
          {user?.role === 'admin' && <NavLink to="/admin" className={linkClass}>Admin dashboard</NavLink>}
          {user ? (
            <button className="btn-ghost" onClick={() => { logout(); navigate('/'); }}>Log out ({user.name.split(' ')[0]})</button>
          ) : (
            <>
              <NavLink to="/login" className={linkClass}>Log in</NavLink>
              <Link to="/register" className="btn-primary">Create account</Link>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
