/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'] },
      colors: {
        ink: '#1B2430',
        paper: '#F2F5F7',
        line: '#D5DCE3',
        leaf: { DEFAULT: '#0E7C66', dark: '#0A5C4B', soft: '#DDF1EC' },
        marigold: { DEFAULT: '#F2A93B', soft: '#FDF0D8' },
        rust: { DEFAULT: '#B4411C', soft: '#F9E3DA' },
      },
    },
  },
  plugins: [],
};
