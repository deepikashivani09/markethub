import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { query } from '../db.js';
import { HttpError, asyncHandler } from '../utils/errors.js';

export const signToken = (user) => jwt.sign({ sub: user.id }, config.jwtSecret, { expiresIn: '7d' });

export const authenticate = asyncHandler(async (req, _res, next) => {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) throw new HttpError(401, 'Please log in to continue');
  let payload;
  try {
    payload = jwt.verify(token, config.jwtSecret);
  } catch {
    throw new HttpError(401, 'Your session has expired. Please log in again');
  }
  const { rows } = await query('SELECT id, name, email, role, shop_name, status FROM users WHERE id = $1', [payload.sub]);
  const user = rows[0];
  if (!user) throw new HttpError(401, 'Account not found');
  if (user.status === 'suspended') throw new HttpError(403, 'This account has been suspended');
  req.user = user;
  next();
});

// Role-based access control.
export const authorize = (...roles) => (req, _res, next) => {
  if (!roles.includes(req.user.role)) return next(new HttpError(403, 'You do not have access to this area'));
  next();
};

export const requireApprovedVendor = (req, _res, next) => {
  if (req.user.status !== 'active') return next(new HttpError(403, 'Your vendor account is awaiting admin approval'));
  next();
};
