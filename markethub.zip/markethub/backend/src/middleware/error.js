import { HttpError } from '../utils/errors.js';

export const notFound = (_req, _res, next) => next(new HttpError(404, 'Not found'));

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, _req, res, _next) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  if (err.code === '23505') return res.status(409).json({ error: 'That value is already in use' });
  if (err.code === '23514') return res.status(409).json({ error: 'That change would break a data rule (for example, negative stock)' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our side' });
}
