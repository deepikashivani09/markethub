import app from './app.js';
import { config } from './config.js';
import { expireStaleOrders } from './services/orders.js';
import { paymentMode } from './services/payments.js';

app.listen(config.port, () => {
  console.log(`MarketHub API on http://localhost:${config.port}  (payments: ${paymentMode()} mode)`);
});

// Every minute, release stock held by unpaid orders whose reservation has run out.
setInterval(() => expireStaleOrders().catch((e) => console.error('Expiry job failed', e)), 60_000);
