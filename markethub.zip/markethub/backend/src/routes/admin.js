import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { HttpError, asyncHandler, parse } from '../utils/errors.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { ORDERS_WITH_ITEMS_SQL } from '../services/orders.js';

const router = Router();
router.use(authenticate, authorize('admin'));

router.get('/stats', asyncHandler(async (_req, res) => {
  const { rows } = await query(`
    SELECT
      (SELECT count(*)::int FROM users WHERE role = 'customer') AS customers,
      (SELECT count(*)::int FROM users WHERE role = 'vendor' AND status = 'active') AS vendors,
      (SELECT count(*)::int FROM users WHERE role = 'vendor' AND status = 'pending') AS pending_vendors,
      (SELECT count(*)::int FROM products WHERE is_active) AS products,
      (SELECT count(*)::int FROM orders) AS orders,
      (SELECT COALESCE(sum(total_cents), 0)::int FROM orders WHERE payment_status = 'paid') AS revenue_cents`);
  res.json(rows[0]);
}));

router.get('/users', asyncHandler(async (_req, res) => {
  const { rows } = await query(
    `SELECT id, name, email, role, shop_name, status, created_at FROM users WHERE role <> 'admin' ORDER BY id DESC`
  );
  res.json(rows);
}));

const userStatusSchema = z.object({ status: z.enum(['active', 'suspended']) });

router.patch('/users/:id/status', asyncHandler(async (req, res) => {
  const { status } = parse(userStatusSchema, req.body);
  const { rows } = await query(
    `UPDATE users SET status = $2 WHERE id = $1 AND role <> 'admin' RETURNING id, name, email, role, shop_name, status`,
    [req.params.id, status]
  );
  if (!rows[0]) throw new HttpError(404, 'User not found');
  res.json(rows[0]);
}));

router.get('/orders', asyncHandler(async (_req, res) => {
  const { rows } = await query(
    `SELECT x.*, c.name AS customer_name FROM (${ORDERS_WITH_ITEMS_SQL} GROUP BY o.id) x
       JOIN users c ON c.id = x.customer_id ORDER BY x.id DESC LIMIT 200`
  );
  res.json(rows);
}));

export default router;
