import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { z } from 'zod';
import { query } from '../db.js';
import { HttpError, asyncHandler, parse } from '../utils/errors.js';
import { authenticate, signToken } from '../middleware/auth.js';

const router = Router();

const registerSchema = z
  .object({
    name: z.string().trim().min(2, 'Enter your name'),
    email: z.string().trim().toLowerCase().email('Enter a valid email address'),
    password: z.string().min(8, 'Password must be at least 8 characters'),
    role: z.enum(['customer', 'vendor']).default('customer'),
    shopName: z.string().trim().min(2, 'Enter a shop name').optional(),
  })
  .refine((d) => d.role !== 'vendor' || d.shopName, { message: 'Vendors need a shop name', path: ['shopName'] });

router.post('/register', asyncHandler(async (req, res) => {
  const d = parse(registerSchema, req.body);
  const hash = await bcrypt.hash(d.password, 10);
  const status = d.role === 'vendor' ? 'pending' : 'active'; // vendors need admin approval
  const { rows } = await query(
    `INSERT INTO users (name, email, password_hash, role, shop_name, status) VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING id, name, email, role, shop_name, status`,
    [d.name, d.email, hash, d.role, d.role === 'vendor' ? d.shopName : null, status]
  ).catch((e) => {
    if (e.code === '23505') throw new HttpError(409, 'An account with this email already exists');
    throw e;
  });
  res.status(201).json({ token: signToken(rows[0]), user: rows[0] });
}));

const loginSchema = z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1) });

router.post('/login', asyncHandler(async (req, res) => {
  const d = parse(loginSchema, req.body);
  const { rows } = await query('SELECT * FROM users WHERE email = $1', [d.email]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(d.password, user.password_hash))) throw new HttpError(401, 'Incorrect email or password');
  if (user.status === 'suspended') throw new HttpError(403, 'This account has been suspended');
  const { password_hash, ...safe } = user;
  res.json({ token: signToken(safe), user: safe });
}));

router.get('/me', authenticate, (req, res) => res.json({ user: req.user }));

export default router;
