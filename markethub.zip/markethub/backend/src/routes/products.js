import { Router } from 'express';
import { query } from '../db.js';
import { HttpError, asyncHandler } from '../utils/errors.js';

const router = Router();

const SORTS = {
  newest: 'p.created_at DESC',
  price_asc: 'p.price_cents ASC',
  price_desc: 'p.price_cents DESC',
};

router.get('/categories', asyncHandler(async (_req, res) => {
  const { rows } = await query(
    `SELECT DISTINCT p.category FROM products p JOIN users u ON u.id = p.vendor_id
      WHERE p.is_active AND u.status = 'active' ORDER BY p.category`
  );
  res.json(rows.map((r) => r.category));
}));

router.get('/', asyncHandler(async (req, res) => {
  const { search, category, minPrice, maxPrice, sort = 'newest' } = req.query;
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = 12;
  const where = ["p.is_active", "u.status = 'active'"];
  const params = [];
  const add = (sql, value) => { params.push(value); where.push(sql.replaceAll('?', `$${params.length}`)); };

  if (search) add('(p.name ILIKE ? OR p.description ILIKE ?)', `%${search}%`);
  if (category) add('p.category = ?', category);
  if (minPrice) add('p.price_cents >= ?', Math.round(Number(minPrice) * 100));
  if (maxPrice) add('p.price_cents <= ?', Math.round(Number(maxPrice) * 100));

  const from = `FROM products p JOIN users u ON u.id = p.vendor_id WHERE ${where.join(' AND ')}`;
  const total = (await query(`SELECT count(*)::int AS n ${from}`, params)).rows[0].n;
  const { rows } = await query(
    `SELECT p.id, p.name, p.description, p.price_cents, p.stock, p.category, p.image_url, u.shop_name
       ${from} ORDER BY ${SORTS[sort] || SORTS.newest} LIMIT ${limit} OFFSET ${(page - 1) * limit}`,
    params
  );
  res.json({ items: rows, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
}));

router.get('/:id', asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT p.id, p.name, p.description, p.price_cents, p.stock, p.category, p.image_url, u.shop_name
       FROM products p JOIN users u ON u.id = p.vendor_id
      WHERE p.id = $1 AND p.is_active AND u.status = 'active'`,
    [req.params.id]
  );
  if (!rows[0]) throw new HttpError(404, 'Product not found');
  res.json(rows[0]);
}));

export default router;
