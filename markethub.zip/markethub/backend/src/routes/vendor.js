import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { HttpError, asyncHandler, parse } from '../utils/errors.js';
import { authenticate, authorize, requireApprovedVendor } from '../middleware/auth.js';
import { STATUSES } from '../utils/orderStateMachine.js';
import { transitionItem } from '../services/orders.js';

const router = Router();
router.use(authenticate, authorize('vendor'));

const productSchema = z.object({
  name: z.string().trim().min(2, 'Enter a product name'),
  description: z.string().trim().default(''),
  price: z.coerce.number().positive('Price must be more than 0'),
  stock: z.coerce.number().int().min(0, 'Stock cannot be negative'),
  category: z.string().trim().min(2, 'Enter a category'),
  image_url: z.string().trim().url('Enter a valid image URL').optional().or(z.literal('')),
});

router.get('/products', asyncHandler(async (req, res) => {
  const { rows } = await query('SELECT * FROM products WHERE vendor_id = $1 AND is_active ORDER BY id DESC', [req.user.id]);
  res.json(rows);
}));

router.post('/products', requireApprovedVendor, asyncHandler(async (req, res) => {
  const d = parse(productSchema, req.body);
  const { rows } = await query(
    `INSERT INTO products (vendor_id, name, description, price_cents, stock, category, image_url)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [req.user.id, d.name, d.description, Math.round(d.price * 100), d.stock, d.category, d.image_url || null]
  );
  res.status(201).json(rows[0]);
}));

router.put('/products/:id', requireApprovedVendor, asyncHandler(async (req, res) => {
  const d = parse(productSchema, req.body);
  const { rows } = await query(
    `UPDATE products SET name=$3, description=$4, price_cents=$5, stock=$6, category=$7, image_url=$8
      WHERE id=$1 AND vendor_id=$2 AND is_active RETURNING *`,
    [req.params.id, req.user.id, d.name, d.description, Math.round(d.price * 100), d.stock, d.category, d.image_url || null]
  );
  if (!rows[0]) throw new HttpError(404, 'Product not found');
  res.json(rows[0]);
}));

// Soft delete so past orders keep their product reference.
router.delete('/products/:id', asyncHandler(async (req, res) => {
  const r = await query('UPDATE products SET is_active = FALSE WHERE id = $1 AND vendor_id = $2', [req.params.id, req.user.id]);
  if (!r.rowCount) throw new HttpError(404, 'Product not found');
  res.status(204).end();
}));

router.get('/order-items', asyncHandler(async (req, res) => {
  const { rows } = await query(
    `SELECT oi.*, o.payment_status, o.shipping_address, o.created_at, c.name AS customer_name
       FROM order_items oi
       JOIN orders o ON o.id = oi.order_id
       JOIN users c ON c.id = o.customer_id
      WHERE oi.vendor_id = $1 ORDER BY oi.id DESC`,
    [req.user.id]
  );
  res.json(rows);
}));

const statusSchema = z.object({ status: z.enum(STATUSES) });

router.patch('/order-items/:id/status', asyncHandler(async (req, res) => {
  const { status } = parse(statusSchema, req.body);
  res.json(await transitionItem(Number(req.params.id), status, req.user));
}));

export default router;
