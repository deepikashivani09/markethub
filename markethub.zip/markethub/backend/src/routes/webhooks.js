import { config } from '../config.js';
import { HttpError } from '../utils/errors.js';
import { stripe } from '../services/payments.js';
import { cancelOrder, markOrderPaid } from '../services/orders.js';

// Mounted with express.raw() BEFORE express.json(): Stripe signs the exact raw bytes.
export async function stripeWebhook(req, res) {
  if (!stripe) throw new HttpError(404, 'Stripe is not configured');
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], config.stripeWebhookSecret);
  } catch (err) {
    throw new HttpError(400, `Webhook signature check failed: ${err.message}`);
  }

  const session = event.data.object;
  const orderId = Number(session.metadata?.orderId);

  switch (event.type) {
    case 'checkout.session.completed':
    case 'checkout.session.async_payment_succeeded':
      if (orderId && session.payment_status === 'paid') await markOrderPaid(orderId, session.payment_intent);
      break;
    case 'checkout.session.expired':
    case 'checkout.session.async_payment_failed':
      if (orderId) await cancelOrder(orderId, { role: 'system' }).catch(() => {}); // already paid/shipped: ignore
      break;
    default:
      break;
  }
  res.json({ received: true });
}
