import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { HttpError, asyncHandler, parse } from '../utils/errors.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();
router.use(authenticate, authorize('customer'));

const CART_SQL = `
  SELECT ci.product_id, ci.quantity, p.name, p.price_cents, p.stock, p.image_url, u.shop_name
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    JOIN users u ON u.id = p.vendor_id
   WHERE ci.user_id = $1 AND p.is_active
   ORDER BY ci.product_id`;

router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await query(CART_SQL, [req.user.id]);
  res.json({ items: rows, total_cents: rows.reduce((s, r) => s + r.price_cents * r.quantity, 0) });
}));

const qtySchema = z.object({ quantity: z.number().int().min(0).max(99) });

// Set the quantity of a product in the cart (0 removes it).
router.put('/:productId', asyncHandler(async (req, res) => {
  const { quantity } = parse(qtySchema, req.body);
  const productId = Number(req.params.productId);
  if (quantity === 0) {
    await query('DELETE FROM cart_items WHERE user_id = $1 AND product_id = $2', [req.user.id, productId]);
  } else {
    const { rows } = await query(
      `SELECT p.stock FROM products p JOIN users u ON u.id = p.vendor_id
        WHERE p.id = $1 AND p.is_active AND u.status = 'active'`,
      [productId]
    );
    if (!rows[0]) throw new HttpError(404, 'Product not found');
    if (quantity > rows[0].stock) throw new HttpError(409, `Only ${rows[0].stock} left in stock`);
    await query(
      `INSERT INTO cart_items (user_id, product_id, quantity) VALUES ($1, $2, $3)
       ON CONFLICT (user_id, product_id) DO UPDATE SET quantity = EXCLUDED.quantity`,
      [req.user.id, productId, quantity]
    );
  }
  const { rows } = await query(CART_SQL, [req.user.id]);
  res.json({ items: rows, total_cents: rows.reduce((s, r) => s + r.price_cents * r.quantity, 0) });
}));

export default router;
