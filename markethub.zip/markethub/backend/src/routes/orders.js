import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
import { HttpError, asyncHandler, parse } from '../utils/errors.js';
import { authenticate, authorize } from '../middleware/auth.js';
import { cancelOrder, createOrderFromCart, markOrderPaid, ORDERS_WITH_ITEMS_SQL } from '../services/orders.js';
import { createCheckoutSession, paymentMode } from '../services/payments.js';

const router = Router();
router.use(authenticate, authorize('customer'));

router.get('/payment-mode', (_req, res) => res.json({ mode: paymentMode() }));

router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await query(`${ORDERS_WITH_ITEMS_SQL} WHERE o.customer_id = $1 GROUP BY o.id ORDER BY o.id DESC`, [req.user.id]);
  res.json(rows);
}));

const checkoutSchema = z.object({ shippingAddress: z.string().trim().min(10, 'Enter your full shipping address') });

router.post('/checkout', asyncHandler(async (req, res) => {
  const { shippingAddress } = parse(checkoutSchema, req.body);
  const order = await createOrderFromCart(req.user.id, shippingAddress);
  res.status(201).json(order);
}));

async function loadOwnOrder(id, userId) {
  const { rows } = await query('SELECT * FROM orders WHERE id = $1 AND customer_id = $2', [id, userId]);
  if (!rows[0]) throw new HttpError(404, 'Order not found');
  return rows[0];
}

// Start payment. Stripe mode returns a hosted Checkout URL (confirmed later by webhook).
// Demo mode marks the order paid straight away so the whole flow runs without keys.
router.post('/:id/pay', asyncHandler(async (req, res) => {
  const order = await loadOwnOrder(req.params.id, req.user.id);
  if (order.status === 'cancelled') throw new HttpError(409, 'This order was cancelled');
  if (order.payment_status === 'paid') throw new HttpError(409, 'This order is already paid');
  if (paymentMode() === 'stripe') {
    return res.json({ mode: 'stripe', checkoutUrl: await createCheckoutSession(order) });
  }
  await markOrderPaid(order.id, `demo_${Date.now()}`);
  res.json({ mode: 'demo', paid: true });
}));

router.post('/:id/cancel', asyncHandler(async (req, res) => {
  await loadOwnOrder(req.params.id, req.user.id);
  res.json(await cancelOrder(Number(req.params.id), req.user));
}));

export default router;
