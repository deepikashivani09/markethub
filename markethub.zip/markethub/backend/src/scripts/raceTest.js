// Proves the overselling protection: 25 buyers race for 5 units. Exactly 5 must succeed.
import bcrypt from 'bcryptjs';
import { pool } from '../db.js';
import { createOrderFromCart } from '../services/orders.js';

const STOCK = 5;
const BUYERS = 25;
const tag = Date.now();
const hash = await bcrypt.hash('x', 4);

const { rows: [vendor] } = await pool.query(
  `INSERT INTO users (name,email,password_hash,role,shop_name) VALUES ('Race Vendor',$1,$2,'vendor','Race Shop') RETURNING id`,
  [`race-v-${tag}@test.local`, hash]
);
const { rows: [product] } = await pool.query(
  `INSERT INTO products (vendor_id,name,price_cents,stock,category) VALUES ($1,'Last-units widget',1000,$2,'Test') RETURNING id`,
  [vendor.id, STOCK]
);
const buyers = [];
for (let i = 0; i < BUYERS; i++) {
  const { rows: [u] } = await pool.query(
    `INSERT INTO users (name,email,password_hash,role) VALUES ($1,$2,$3,'customer') RETURNING id`,
    [`Racer ${i}`, `race-c-${tag}-${i}@test.local`, hash]
  );
  await pool.query('INSERT INTO cart_items (user_id,product_id,quantity) VALUES ($1,$2,1)', [u.id, product.id]);
  buyers.push(u.id);
}

const results = await Promise.allSettled(buyers.map((id) => createOrderFromCart(id, 'Race test address, Tirunelveli')));
const ok = results.filter((r) => r.status === 'fulfilled').length;
const { rows: [after] } = await pool.query('SELECT stock FROM products WHERE id = $1', [product.id]);

console.log(`Stock: ${STOCK} | buyers: ${BUYERS} | orders placed: ${ok} | rejected: ${BUYERS - ok} | stock left: ${after.stock}`);
console.log(ok === STOCK && after.stock === 0 ? 'PASS: no overselling' : 'FAIL: overselling detected');

// Clean up test data.
await pool.query('DELETE FROM orders WHERE customer_id = ANY($1)', [buyers]);
await pool.query('DELETE FROM users WHERE id = ANY($1) OR id = $2', [buyers, vendor.id]);
await pool.end();
process.exit(ok === STOCK ? 0 : 1);
