import bcrypt from 'bcryptjs';
import { pool } from '../db.js';

const { rows } = await pool.query('SELECT count(*)::int AS n FROM users');
if (rows[0].n > 0) {
  console.log('Database already has users, skipping seed.');
  await pool.end();
  process.exit(0);
}

const hash = await bcrypt.hash('Passw0rd!', 10);
const user = async (name, email, role, shop = null) =>
  (await pool.query(
    `INSERT INTO users (name, email, password_hash, role, shop_name, status) VALUES ($1,$2,$3,$4,$5,'active') RETURNING id`,
    [name, email, hash, role, shop]
  )).rows[0].id;

await user('Site Admin', 'admin@markethub.test', 'admin');
const v1 = await user('Meena Pottery', 'vendor1@markethub.test', 'vendor', 'Meena Pottery Studio');
const v2 = await user('Karthik Textiles', 'vendor2@markethub.test', 'vendor', 'Karthik Handloom House');
await user('Deepa Customer', 'customer@markethub.test', 'customer');

const products = [
  [v1, 'Terracotta water jug', 'Hand-thrown 2 litre jug that keeps water cool.', 64900, 25, 'Home'],
  [v1, 'Glazed coffee mug set (4)', 'Stoneware mugs, dishwasher safe.', 119900, 12, 'Home'],
  [v1, 'Clay planter, medium', 'Unglazed planter with drainage hole.', 34900, 40, 'Garden'],
  [v1, 'Ceramic serving bowl', 'Wide bowl for salads and curries.', 79900, 3, 'Home'],
  [v1, 'Diya lamp pack (12)', 'Festival-ready clay lamps.', 24900, 100, 'Festive'],
  [v2, 'Handloom cotton saree', 'Soft cotton with zari border.', 289900, 8, 'Clothing'],
  [v2, 'Kerala kasavu dupatta', 'Lightweight handwoven dupatta.', 89900, 20, 'Clothing'],
  [v2, 'Cotton bath towel', 'Thick, quick-drying, 450 GSM.', 44900, 60, 'Home'],
  [v2, 'Jute tote bag', 'Sturdy tote with cotton lining.', 29900, 75, 'Accessories'],
  [v2, 'Block-print table runner', 'Natural dyes, 180 cm.', 54900, 15, 'Home'],
  [v2, 'Handwoven floor mat', 'Reversible cotton mat, 60 x 90 cm.', 69900, 1, 'Home'],
  [v1, 'Brass-finish incense holder', 'Compact holder with ash catcher.', 19900, 50, 'Festive'],
];
for (const [vendor, name, desc, price, stock, cat] of products) {
  await pool.query(
    `INSERT INTO products (vendor_id, name, description, price_cents, stock, category) VALUES ($1,$2,$3,$4,$5,$6)`,
    [vendor, name, desc, price, stock, cat]
  );
}

console.log('Seeded. Log in with any of these (password: Passw0rd!)');
console.log('  admin@markethub.test | vendor1@markethub.test | vendor2@markethub.test | customer@markethub.test');
await pool.end();
