import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from '../db.js';

const sql = fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), '../../sql/schema.sql'), 'utf8');
await pool.query(sql);
console.log('Database schema is ready.');
await pool.end();
