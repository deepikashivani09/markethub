import Stripe from 'stripe';
import { config } from '../config.js';
import { query } from '../db.js';

export const stripe = config.stripeSecretKey ? new Stripe(config.stripeSecretKey) : null;
export const paymentMode = () => (stripe ? 'stripe' : 'demo');

export async function createCheckoutSession(order) {
  const { rows: items } = await query('SELECT name, unit_price_cents, quantity FROM order_items WHERE order_id = $1 AND status <> \'cancelled\'', [order.id]);
  // Stripe requires the session to live for at least 30 minutes.
  const expiresAt = Math.floor(Date.now() / 1000) + Math.max(30, config.reservationMinutes) * 60;
  const session = await stripe.checkout.sessions.create({
    mode: 'payment',
    client_reference_id: String(order.id),
    metadata: { orderId: String(order.id) },
    expires_at: expiresAt,
    line_items: items.map((i) => ({
      quantity: i.quantity,
      price_data: { currency: config.currency, unit_amount: i.unit_price_cents, product_data: { name: i.name } },
    })),
    success_url: `${config.clientUrl}/orders?paid=${order.id}`,
    cancel_url: `${config.clientUrl}/orders`,
  });
  return session.url;
}
