import { query, withTransaction } from '../db.js';
import { HttpError } from '../utils/errors.js';
import { canTransition, deriveOrderStatus } from '../utils/orderStateMachine.js';
import { config } from '../config.js';

/**
 * Checkout: turn the cart into an order and RESERVE stock atomically.
 *
 * Race-condition handling: every decrement is a single conditional UPDATE
 * (stock = stock - qty WHERE stock >= qty). Postgres row-locks the product, so
 * two buyers racing for the last unit are serialised: the second UPDATE
 * re-checks the condition after the first commits and matches 0 rows.
 * Products are processed in id order to avoid deadlocks between carts.
 * The CHECK (stock >= 0) constraint is a second line of defence.
 */
export function createOrderFromCart(userId, shippingAddress) {
  return withTransaction(async (c) => {
    const { rows: cart } = await c.query('SELECT product_id FROM cart_items WHERE user_id = $1', [userId]);
    if (!cart.length) throw new HttpError(400, 'Your cart is empty');

    const { rows: items } = await c.query(
      `SELECT ci.product_id, ci.quantity, p.name, p.price_cents, p.vendor_id
         FROM cart_items ci
         JOIN products p ON p.id = ci.product_id AND p.is_active
         JOIN users u ON u.id = p.vendor_id AND u.status = 'active'
        WHERE ci.user_id = $1
        ORDER BY ci.product_id`,
      [userId]
    );
    if (items.length !== cart.length) throw new HttpError(409, 'Some items in your cart are no longer available. Remove them and try again');

    let total = 0;
    for (const it of items) {
      const r = await c.query('UPDATE products SET stock = stock - $2 WHERE id = $1 AND stock >= $2 RETURNING stock', [it.product_id, it.quantity]);
      if (!r.rowCount) throw new HttpError(409, `Not enough stock for "${it.name}". Lower the quantity and try again`);
      total += it.price_cents * it.quantity;
    }

    const { rows: [order] } = await c.query(
      `INSERT INTO orders (customer_id, total_cents, shipping_address, expires_at)
       VALUES ($1, $2, $3, now() + make_interval(mins => $4::int)) RETURNING *`,
      [userId, total, shippingAddress, config.reservationMinutes]
    );
    for (const it of items) {
      await c.query(
        `INSERT INTO order_items (order_id, product_id, vendor_id, name, unit_price_cents, quantity)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [order.id, it.product_id, it.vendor_id, it.name, it.price_cents, it.quantity]
      );
    }
    await c.query('DELETE FROM cart_items WHERE user_id = $1', [userId]);
    return order;
  });
}

/** Called by the Stripe webhook (or the demo pay button). Idempotent. */
export function markOrderPaid(orderId, paymentRef) {
  return withTransaction(async (c) => {
    const { rows: [order] } = await c.query('SELECT * FROM orders WHERE id = $1 FOR UPDATE', [orderId]);
    if (!order) throw new HttpError(404, 'Order not found');
    if (order.payment_status === 'paid') return order;

    if (order.status === 'cancelled') {
      // Paid after the reservation expired: stock was already released, so flag the money for refund.
      const r = await c.query(
        `UPDATE orders SET payment_status = 'paid', payment_ref = $2, refund_due_cents = total_cents, expires_at = NULL
          WHERE id = $1 RETURNING *`,
        [orderId, paymentRef]
      );
      return r.rows[0];
    }
    const r = await c.query(
      `UPDATE orders SET payment_status = 'paid', payment_ref = $2, expires_at = NULL WHERE id = $1 RETURNING *`,
      [orderId, paymentRef]
    );
    return r.rows[0];
  });
}

/**
 * Move one order line to a new state. Enforces the state machine, who may do it,
 * stock restoration on cancel, and recomputes the parent order's status.
 */
export async function transitionItemTx(c, itemId, to, actor) {
  const { rows: [item] } = await c.query(
    `SELECT oi.*, o.customer_id, o.payment_status
       FROM order_items oi JOIN orders o ON o.id = oi.order_id
      WHERE oi.id = $1 FOR UPDATE`,
    [itemId]
  );
  if (!item) throw new HttpError(404, 'Order item not found');

  const privileged = actor.role === 'admin' || actor.role === 'system';
  if (actor.role === 'vendor' && item.vendor_id !== actor.id) throw new HttpError(403, 'This item belongs to another vendor');
  if (actor.role === 'customer') {
    if (item.customer_id !== actor.id) throw new HttpError(403, 'This is not your order');
    if (to !== 'cancelled') throw new HttpError(403, 'Customers can only cancel orders');
  }
  if (!privileged && actor.role !== 'vendor' && actor.role !== 'customer') throw new HttpError(403, 'Not allowed');

  if (!canTransition(item.status, to)) throw new HttpError(409, `An item that is ${item.status} cannot move to ${to}`);
  if (to !== 'cancelled' && item.payment_status !== 'paid') throw new HttpError(409, 'This order has not been paid yet');

  await c.query('UPDATE order_items SET status = $2 WHERE id = $1', [itemId, to]);

  if (to === 'cancelled') {
    await c.query('UPDATE products SET stock = stock + $2 WHERE id = $1', [item.product_id, item.quantity]);
    if (item.payment_status === 'paid') {
      await c.query('UPDATE orders SET refund_due_cents = refund_due_cents + $2 WHERE id = $1', [item.order_id, item.unit_price_cents * item.quantity]);
    }
  }

  const { rows: siblings } = await c.query('SELECT status FROM order_items WHERE order_id = $1', [item.order_id]);
  const orderStatus = deriveOrderStatus(siblings.map((s) => s.status));
  await c.query('UPDATE orders SET status = $2 WHERE id = $1', [item.order_id, orderStatus]);
  return { itemId, status: to, orderStatus };
}

export const transitionItem = (itemId, to, actor) => withTransaction((c) => transitionItemTx(c, itemId, to, actor));

/** Cancel a whole order (customer, admin, or the expiry job). Allowed until something ships. */
export function cancelOrder(orderId, actor) {
  return withTransaction(async (c) => {
    const { rows: [order] } = await c.query('SELECT * FROM orders WHERE id = $1 FOR UPDATE', [orderId]);
    if (!order) throw new HttpError(404, 'Order not found');
    if (actor.role === 'customer' && order.customer_id !== actor.id) throw new HttpError(403, 'This is not your order');

    const { rows: items } = await c.query('SELECT id, status FROM order_items WHERE order_id = $1 ORDER BY id', [orderId]);
    if (items.some((i) => i.status === 'shipped' || i.status === 'delivered')) {
      throw new HttpError(409, 'Part of this order has already shipped, so it can no longer be cancelled');
    }
    for (const i of items.filter((x) => x.status !== 'cancelled')) {
      await transitionItemTx(c, i.id, 'cancelled', actor);
    }
    return { id: orderId, status: 'cancelled' };
  });
}

/** Release stock held by orders that were never paid. Run on an interval. */
export async function expireStaleOrders() {
  const { rows } = await query(
    `SELECT id FROM orders WHERE payment_status = 'unpaid' AND status <> 'cancelled' AND expires_at IS NOT NULL AND expires_at < now()`
  );
  for (const { id } of rows) {
    try {
      await cancelOrder(id, { role: 'system' });
      console.log(`Released reserved stock for unpaid order #${id}`);
    } catch (err) {
      console.error(`Could not expire order #${id}:`, err.message);
    }
  }
}

export const ORDERS_WITH_ITEMS_SQL = `
  SELECT o.*, COALESCE(json_agg(json_build_object(
           'id', oi.id, 'product_id', oi.product_id, 'name', oi.name, 'quantity', oi.quantity,
           'unit_price_cents', oi.unit_price_cents, 'status', oi.status, 'vendor_name', v.shop_name
         ) ORDER BY oi.id) FILTER (WHERE oi.id IS NOT NULL), '[]') AS items
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    LEFT JOIN users v ON v.id = oi.vendor_id`;
