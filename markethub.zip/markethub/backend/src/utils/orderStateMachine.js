// Order state machine: Pending -> Packed -> Shipped -> Delivered, with Cancelled
// reachable only before an item has shipped.
export const STATUSES = ['pending', 'packed', 'shipped', 'delivered', 'cancelled'];

const TRANSITIONS = {
  pending: ['packed', 'cancelled'],
  packed: ['shipped', 'cancelled'],
  shipped: ['delivered'],
  delivered: [],
  cancelled: [],
};

export const canTransition = (from, to) => TRANSITIONS[from]?.includes(to) ?? false;
export const nextStatuses = (from) => TRANSITIONS[from] ?? [];

// An order is only as far along as its slowest live item. If every item is cancelled, so is the order.
export function deriveOrderStatus(itemStatuses) {
  const live = itemStatuses.filter((s) => s !== 'cancelled');
  if (live.length === 0) return 'cancelled';
  return live.reduce((slowest, s) => (STATUSES.indexOf(s) < STATUSES.indexOf(slowest) ? s : slowest));
}
