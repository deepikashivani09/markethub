import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { config } from './config.js';
import { asyncHandler } from './utils/errors.js';
import { errorHandler, notFound } from './middleware/error.js';
import { stripeWebhook } from './routes/webhooks.js';
import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import cartRoutes from './routes/cart.js';
import orderRoutes from './routes/orders.js';
import vendorRoutes from './routes/vendor.js';
import adminRoutes from './routes/admin.js';

const app = express();
app.use(helmet());
app.use(cors({ origin: config.clientUrl }));

app.post('/api/webhooks/stripe', express.raw({ type: 'application/json' }), asyncHandler(stripeWebhook));

app.use(express.json());
app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/vendor', vendorRoutes);
app.use('/api/admin', adminRoutes);

app.use(notFound);
app.use(errorHandler);

export default app;
